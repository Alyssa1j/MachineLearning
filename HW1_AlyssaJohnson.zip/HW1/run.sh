#!/bin/sh
python3 hw1_results.py