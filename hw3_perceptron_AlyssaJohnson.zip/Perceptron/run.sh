#!/bin/sh
python3 h3_results.py