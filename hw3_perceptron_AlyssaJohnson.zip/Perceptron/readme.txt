run.sh will run h3_results.py which are the same results produced for hw3 part 2

perceptron.py has all the different perceptron methods, it assumes that all X data is folded with labels. 