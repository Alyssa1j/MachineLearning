#!/bin/sh
python3 hw5.py